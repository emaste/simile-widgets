﻿/** @constructor */
function RecordSet() {
    this.getRecords = function(){
    }
}

/*
[
    {
        symbols: [
            {
                doc: { tags: [] },
                returns: [],
                type: "",
                properties: [],
                isa: "CONSTRUCTOR",
                desc: "",
                alias: "RecordSet",
                memberof: "",
                params: [],
                methods: [ { name: "getRecords", alias: "RecordSet.getRecords" } ],
                name: "RecordSet"
            },
            {
                doc: { tags: [] },
                returns: [],
                type: "",
                properties: [],
                isa: "FUNCTION",
                desc: "undocumented",
                alias: "RecordSet.getRecords",
                memberof: "RecordSet",
                params: [],
                methods: [],
                name: "getRecords"
            }
        ],
        overview: {
            doc: { tags: [] },
            returns: [],
            type: "",
            properties: [],
            isa: "FILE",
            desc: "No overview provided.",
            alias: "examples/data/methods1.js",
            memberof: "",
            params: [],
            methods: [],
            name: "examples/data/methods1.js"
        }
    }
]
*/
﻿/** The maximum number of records. */
var LIMIT = 99;

/*
[
    {
        symbols: [
            {
                doc: { tags: [] },
                returns: [],
                type: "",
                properties: [],
                isa: "OBJECT",
                desc: "The maximum number of records.",
                alias: "LIMIT",
                memberof: "",
                params: [],
                methods: [],
                name: "LIMIT"
            }
        ],
        overview: {
            doc: { tags: [] },
            returns: [],
            type: "",
            properties: [],
            isa: "FILE",
            desc: "No overview provided.",
            alias: "examples/data/variables1.js",
            memberof: "",
            params: [],
            methods: [],
            name: "examples/data/variables1.js"
        }
    }
]
*/